version_info = (0, 9, 0)

__version__ = '%s.%s.%s' % (version_info[0], version_info[1], version_info[2])
