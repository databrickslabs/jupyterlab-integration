#   Copyright 2019 Bernhard Walter
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import os
import subprocess
import tempfile

import inquirer
from inquirer.themes import Default, term

import databricks_jupyterlab
from databricks_jupyterlab.remote import Dark


import conda.cli.python_api as Conda
import sys


def get_env_file(module_path):
    def expand(f):
        return os.path.join(module_path, "dbr-env-file-plugins", f)
    
    env_files = os.listdir(os.path.join(module_path, "env_files"))

    choice = [
        inquirer.List('env_id',
                    message='Which environment do you want to mirror?',
                    choices=[os.path.splitext(env_file)[0] for env_file in env_files])
    ]
    answer = inquirer.prompt(choice, theme=Dark())
    env_file = answer["env_id"] + ".yml"

    return env_file

def install_env(enf_file, env_name):
    try:
        (stdout_str, stderr_str, return_code_int) = Conda.run_command(
            Conda.Commands.INSTALL, 
            ["env", "create", "-n", env_name, "-f", env_file],
            use_exception_handler=True,
            stdout=sys.stdout, 
            stderr=sys.stderr)
        print(stdout_str, stderr_str, return_code_int)
    except:
        print("Error while installing conda environment")
        sys.exit(1)

def install_labextions():
    pass

def install(env_name):
    module_path = os.path.dirname(databricks_jupyterlab.__file__)
    env_file = get_env_file(module_path)
    install_env(env_file, env_name)
    os.unlink(env_file)
